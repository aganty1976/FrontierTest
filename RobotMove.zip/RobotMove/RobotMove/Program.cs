﻿using System;


class Robot
{

    // function to find final position of
    // robot after the complete movement
    static int movedXposition = 0;
    static int movedYposition = 0;
    static string movedFacing = "";
    

    // Driver code
    static void Main(string[] args)
    {
        string moveType = "";
        do
        {
            Console.WriteLine("Please enter Operation to perform PLAY for executing your own moves or T1,T2,T3,T4, for exsting test cases or EXIT to stop");

            moveType = Console.ReadLine().ToUpper();
            if (moveType == "T1")
                Testcase1();
            else if (moveType == "T2")
                Testcase2();
            else if (moveType == "T3")
                Testcase3();
            else if (moveType == "T4")
                Testcase4();
            else if (moveType.ToUpper() == "PLAY")
            {
                int x;
                int y;
                string direction = "";
                string userInput = "";
                Console.WriteLine("Enter X-Coordinate to place Robot");
                x = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Y-Coordinate to place Robot");
                y = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Robot Direction");
                direction = Console.ReadLine().ToString();
                placeRobot(x, y, direction);
                Report();
                do
                {
                    Console.WriteLine("Enter actions for Robot like MOVE,LEFT,RIGHT,EXIT, enter exit for placing robot properly");
                    userInput = Console.ReadLine().ToUpper();
                    if (userInput == "MOVE")
                    {
                        Move();
                    }
                    else if (userInput == "LEFT")
                    {
                        left();
                    }
                    else if (userInput == "RIGHT")
                    {
                        right();
                    }
                    Report();
                } while (userInput != "EXIT");
            }
        } while (moveType.ToUpper() != "EXIT");
        ResetRobot();
    }

    //Code for the Report provided in the document
    static void Testcase1()
    {
        try
        {
            Console.WriteLine("Starting Robot");
            placeRobot(0, 0, "NORTH");
            Report();
            Move();
            placeRobot(movedXposition, movedYposition, movedFacing);
            Report();
            placeRobot(0, 0, "NORTH");
            left();
            Report();
            ResetRobot();
            placeRobot(1, 2, "EAST");
            Report();
            Move();
            Move();
            left();
            Move();
            Report();
            ResetRobot();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception Thrown:" + ex.Message);
        }
    }

    //Code for displacing the robot cannot move beyond the grid in the NORTH
    static void Testcase2()
    {
        try
        {
            Console.WriteLine("Starting Robot");
            placeRobot(0, 0, "NORTH");
            Report();
            Move();
            Report();
            Move();
            Report();
            Move();
            Report();
            Move();
            Report();
            Move();
            Report();
            Move();
            Report();
            ResetRobot();
        }
        catch(Exception ex)
        {
            Console.WriteLine("Exception Thrown:" + ex.Message);
        }
    }

    //Code for placing the robot before moving
    static void Testcase3()
    {
        try
        {
            Console.WriteLine("Starting Robot");
            Report();
            Move();
            Report();
            Move();
            Report();
            ResetRobot();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception Thrown:" + ex.Message);
        }
    }

    //Code for placing the robot properly before moving
    static void Testcase4()
    {
        try
        {
            Console.WriteLine("Starting Robot");
            placeRobot(0, 6, "NORTH");
            Report();
            Move();
            Report();
            ResetRobot();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception Thrown:" + ex.Message);
        }
    }

    //Code to Reset robot position so that any Move cannot happen without placing the Robot
    static void ResetRobot()
    {
        movedXposition = 0;
        movedYposition = 0;
        movedFacing = "";
    }

    //code to report the exact position of the Robot after the move
    static void Report()
    {
        Console.WriteLine("position of Robot is(" + movedXposition + "," + movedYposition + "," + movedFacing + ")");
    }

    //code to report a move is not possible as it is at the end of the table
    static void RobotHazard()
    {
        Console.WriteLine("Cannot move Robot may fall off");
    }

    //code to report that he Robot need to be placed before moving
    static void Placeunknown()
    {
        Console.WriteLine("Place the Robot first properly on the Grid, Cannot find the Robot GPS");
    }

    //code for Moving the Robot one step in the direction it is facing
    static void Move()
    {
        if (movedFacing == "" || movedXposition > 5 || movedXposition < 0 || movedYposition < 0 || movedYposition > 5)
            Placeunknown();
        else
        {            
            if (movedFacing.ToUpper() == "NORTH")
            {
                if (movedYposition >= 0 && movedYposition < 5)
                    movedYposition = movedYposition + 1;
                else
                {
                    RobotHazard();
                }
            }
            if (movedFacing.ToUpper() == "EAST")
            {
                if (movedXposition >= 0 && movedXposition < 5)
                    movedXposition = movedXposition + 1;
                else
                {
                    RobotHazard();
                }
            }
            if (movedFacing.ToUpper() == "SOUTH")
            {
                if (movedYposition > 0 && movedYposition <= 5)
                    movedYposition = movedYposition - 1;
                else
                {
                    RobotHazard();
                }
            }
            if (movedFacing.ToUpper() == "WEST")
            {
                if (movedXposition > 0 && movedXposition <= 5)
                    movedXposition = movedXposition - 1;
                else
                {
                    RobotHazard();
                }
            }
        }

    }
    
    //code for placing the Robot at particular coordinates in a particular facing
    static void placeRobot(int x, int y, string facing)
    {
        movedXposition = x;
        movedYposition = y;
        movedFacing = facing.ToUpper();

        if (movedFacing == "" || movedXposition > 5 || movedXposition < 0 || movedYposition < 0 || movedYposition > 5)
        {
            Placeunknown();
            ResetRobot();
        }
        
        //if (x == 0 && y == 5)
        //    facing = "EAST";
        //else if(x == 5 && y == 5)
        //    facing = "SOUTH";
        //else if (x == 5 && y == 0)
        //    facing = "WEST";
        //else if (x == 0 && y == 0)
        //    facing = "NORTH";

        //movedFacing = facing;
    }

    //code for turning the robot right
    static void right()
    {
        if (movedFacing.ToUpper() == "NORTH")
            movedFacing = "EAST";
        else if (movedFacing.ToUpper() == "EAST")
            movedFacing = "SOUTH";
        else if (movedFacing == "SOUTH")
            movedFacing = "WEST";
        else if (movedFacing.ToUpper() == "WEST")
            movedFacing = "NORTH";

    }

    //code for turning the robot left
    static void left()
    {
        if (movedFacing.ToUpper() == "NORTH")
            movedFacing = "WEST";
        else if (movedFacing.ToUpper() == "WEST")
            movedFacing = "SOUTH";
        else if (movedFacing.ToUpper() == "SOUTH")
            movedFacing = "EAST";
        else if (movedFacing.ToUpper() == "EAST")
            movedFacing = "NORTH";

    }
}